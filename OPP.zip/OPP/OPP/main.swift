//
//  main.swift
//  OPP
//
//  Created by Trần Ngọc Tân on 8/26/19.
//  Copyright © 2019 Trần Ngọc Tân. All rights reserved.
//

import Foundation


class Persion: NSObject{
    var name: String?
    var birth: String?
    var role: String?
    
     init(name: String, birth: String, role: String) {
        self.name = name
        self.birth = birth
        self.role = role
    }
    
    func getInfo(style: String) -> String {
    
        return "Name: \(name!), birth: \(formatDate(dateTime: birth!, styleDate: style)), role: \(role!)"
    }
    
    func formatDate(dateTime: String, styleDate: String) -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd/mm/yyyy"
        
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = styleDate
        
        let date: Date? = dateFormatterGet.date(from: dateTime)
        return dateFormatterPrint.string(from: date!);
    }
}

class PM : Persion {
    override init(name: String, birth: String, role: String) {
        super.init(name: name, birth: birth, role: role)
    }
    
    func assign(dev: DEV) -> String {
        dev.setNumberTask()
        return "\(name!) assign for \(dev.name!)"
    }
    
    
    
}

class DEV: Persion {
    var numberTask: Int  = 0
    
    override init(name: String, birth: String, role: String) {
        super.init(name: name, birth: birth, role: role)
    }
    
    
    func report(pm:PM) -> String {
       return "\(name!) report for pm \(pm.name!)"
    }
    
    func setNumberTask() {
        self.numberTask += 1
    }
}


var  pm = PM(name: "Thanh", birth: "22/04/1988", role: "PM")
var  tan = DEV(name: "Tan", birth: "13/11/1995", role: "DEV")
var  ton = DEV(name: "Ton", birth: "12/04/1995", role: "DEV")
var  ten = DEV(name: "Ten", birth: "28/04/1998", role: "DEV")
var  tun = DEV(name: "Tun", birth: "14/07/1999", role: "DEV")

print(pm.assign(dev: tan))
print(ten.report(pm: pm))
print(pm.getInfo(style: "dd MMM yyyy"))
print(ten.getInfo(style: "yyyy-mm-dd"))
var listDEV = [DEV]()

listDEV.append(tan)
listDEV.append(ton)

var allTask: Int = 0
for dev in listDEV{
    if(dev.numberTask > 0){
        allTask += dev.numberTask
    }
}

print("all task: \(allTask)")

var index = 0
while (index <= listDEV.count + 1) {
    if let index = listDEV.firstIndex(where: {$0.numberTask == 0}) {
        listDEV.remove(at: index)
    }
    index += 1
}

for dev in listDEV{
    print(dev.name!)
}
