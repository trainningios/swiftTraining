//
//  ViewController.swift
//  demoUI
//
//  Created by Trần Ngọc Tân on 8/29/19.
//  Copyright © 2019 Trần Ngọc Tân. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    

    }
}

