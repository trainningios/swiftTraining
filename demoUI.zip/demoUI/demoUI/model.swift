//
//  model.swift
//  demoUI
//
//  Created by Trần Ngọc Tân on 8/29/19.
//  Copyright © 2019 Trần Ngọc Tân. All rights reserved.
//

import Foundation

protocol Duck {
    func voice()
}

class Mallar: Duck{
    func voice() {
        print("xin chao")
    }
}
class Robot: Mode, Duck{
    func voice() {
        print("hello")
    }
}
class Mode: NSObject {
    var vietnam = VN (language: "xin chao")
    var japan = JP (language: "kimochi")
    var english = EN (language: "hello" )
    var quackClick: String = "VN"
}

class VN: NSObject {
    var language : String
    init(language: String){
        self.language = language
    }
}
class JP: NSObject {
    var language: String
    init(language: String){
        self.language = language
    }
}
class EN: NSObject{
    var  language : String
    init(language: String){
        self.language = language
    }
    
}
    

